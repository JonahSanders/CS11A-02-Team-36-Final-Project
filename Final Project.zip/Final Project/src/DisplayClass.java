import java.awt.*;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
/**
 * The display method uses some basic GUI design to print out
 * Professor Hickey's face and the text after user's input
 * It also uses a simple TTS to read it out loud
 * @author Jiale Hao
 * @version 1.1
 * @since 2018-11-20
 */
public class DisplayClass{

	public static void display(String[] input) // display method generate a frame to display professor's face and the text
	{
		Image img = null; //initialization object image
		try {
			img = ImageIO.read(new File("Tim Hickey.jpg")); //using ImageIO to read the picture
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		ArrayList<String> story = new ArrayList<String>(); //a resizable array story to
		JFrame frame = new JFrame(); //initialization of a new frame
		frame.setSize(450, 450 + img.getHeight(frame)); //setSize(width,height)
 		frame.setVisible(true); //made this frame visible (since this is the only frame there is)
		Graphics g = frame.getGraphics(); // define a graphics context for this component.
		int len = 0;
		String sum = "";
		for(int i = 0; i<input.length;i++)
		{
			String s = input[i];
			sum += s + " ";
			len += 1 + s.length();
			if(len>65)
			{
				story.add(sum);
				sum = "";
				len = 0;
			}
		}

		while(frame.isVisible())
		{
			for(int i = 0; i<story.size(); i++)
			{
				g.drawString(story.get(i).toString(),10, 40 + 20*i + img.getHeight(frame));
			}
			g.drawImage(img, (450 - img.getWidth(frame))/2, 20, Color.RED, frame);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
