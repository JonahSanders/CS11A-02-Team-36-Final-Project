# CS11A-02-Team-36-Final-Project
CS11A Final Project

# HickeyLibs

HickeyLibs is a fun randomization parody on the traditional game, MadLibs.

## Contributors

This program was made possible by Jonah Sanders, Leah Fernandez, Jiale Hao with
special thanks to Professor Timothy Hickey.
Template was adapted from [makeareadme.com](https://www.makeareadme.com/#mind-reading)

## License
[MIT](https://choosealicense.com/licenses/mit/)
